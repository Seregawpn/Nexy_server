# 🔧 План рефакторинга системы разрешений

**Дата:** 2025-10-12  
**Причина:** Избыточное кеширование и блокировка приложения  
**Цель:** Реактивная система без кеша, проверки "на лету"

---

## ❌ **ТЕКУЩИЕ ПРОБЛЕМЫ:**

1. **Кеш устаревает:** `self.permission_statuses` не обновляется после выдачи разрешений
2. **Блокировка приложения:** `_block_application()` переводит в SLEEPING
3. **Нет повторных проверок:** После выдачи прав в System Settings приложение не узнает
4. **Сложная логика:** Много состояний, флагов, событий

---

## ✅ **НОВАЯ АРХИТЕКТУРА:**

### Принципы:
- ❌ **НЕТ КЕША** - всегда проверяем свежий статус
- ❌ **НЕТ БЛОКИРОВКИ** - не переводим в SLEEPING
- ✅ **ПРОВЕРКА ПЕРЕД ДЕЙСТВИЕМ** - каждый модуль проверяет свои права
- ✅ **АВТОМАТИЧЕСКИЙ ЗАПРОС** - если нет прав, запрашиваем сразу

---

## 📋 **ШАГ 1: Удалить кеш и блокировку**

### Файл: `integration/integrations/permissions_integration.py`

**Удалить:**
```python
self.permission_statuses = {}  # ❌ УДАЛИТЬ
self._app_blocked = None       # ❌ УДАЛИТЬ
```

**Удалить методы:**
```python
async def _block_application(self):    # ❌ УДАЛИТЬ
async def _unblock_application(self):  # ❌ УДАЛИТЬ
async def _check_critical_permissions(self):  # ❌ УДАЛИТЬ
async def _are_critical_permissions_granted(self):  # ❌ УДАЛИТЬ
```

---

## 📋 **ШАГ 2: Новый метод _refresh_permissions**

```python
async def _refresh_permissions(self) -> Dict[PermissionType, PermissionResult]:
    """Получить свежие статусы всех разрешений (без кеша)"""
    try:
        results = await self.permission_manager.check_all_permissions()
        
        # Публикуем события для каждого разрешения
        for perm_type, result in results.items():
            await self.event_bus.publish("permissions.status_checked", {
                "permission": perm_type.value,
                "status": result.status.value,
                "success": result.success,
                "message": result.message
            })
        
        return results
    except Exception as e:
        logger.error(f"❌ Ошибка обновления статусов разрешений: {e}")
        return {}
```

---

## 📋 **ШАГ 3: Новый метод _evaluate_permissions**

```python
async def _evaluate_permissions(self, results: Dict[PermissionType, PermissionResult]):
    """Оценить статусы и запросить недостающие разрешения"""
    try:
        # Вычисляем отсутствующие критичные разрешения
        missing = {
            perm: res.status 
            for perm, res in results.items() 
            if perm in self.critical_permissions 
            and res.status != PermissionStatus.GRANTED
        }
        
        if not missing:
            logger.info("✅ Все критичные разрешения предоставлены")
            await self.event_bus.publish("permissions.all_granted", {
                "permissions": [p.value for p in self.critical_permissions]
            })
            return
        
        # Логируем отсутствующие разрешения
        missing_names = [p.value for p in missing.keys()]
        logger.warning(f"⚠️ Отсутствуют критичные разрешения: {missing_names}")
        
        # Публикуем событие
        await self.event_bus.publish("permissions.missing", {
            "missing": [p.value for p in missing.keys()],
            "statuses": {p.value: s.value for p, s in missing.items()}
        })
        
        # Запрашиваем недостающие разрешения (асинхронно, не блокируя)
        asyncio.create_task(self._request_required_permissions(missing))
        
    except Exception as e:
        logger.error(f"❌ Ошибка оценки разрешений: {e}")
```

---

## 📋 **ШАГ 4: Переделать _request_required_permissions**

```python
async def _request_required_permissions(self, missing: Optional[Dict[PermissionType, PermissionStatus]] = None):
    """Запросить недостающие разрешения"""
    try:
        if self._request_in_progress:
            logger.info("⚠️ Запрос прав уже выполняется")
            return
        
        self._request_in_progress = True
        
        # Если missing не передан, проверяем сами
        if missing is None:
            results = await self._refresh_permissions()
            missing = {
                perm: res.status 
                for perm, res in results.items() 
                if perm in self.critical_permissions 
                and res.status != PermissionStatus.GRANTED
            }
        
        if not missing:
            logger.info("✅ Запрос не нужен - все разрешения уже предоставлены")
            return
        
        logger.info(f"🔐 Запрашиваем разрешения: {[p.value for p in missing.keys()]}")
        
        # Если PyObjC доступен - показываем системные диалоги
        if MACOS_IMPORTS_AVAILABLE:
            await self._request_permissions_sequential(missing)
        else:
            logger.warning("⚠️ PyObjC недоступен - автоматические диалоги отключены")
            logger.info("ℹ️ Откройте System Settings вручную:")
            for perm in missing.keys():
                if perm == PermissionType.MICROPHONE:
                    subprocess.run(["open", "x-apple.systempreferences:com.apple.preference.security?Privacy_Microphone"], check=False)
                elif perm == PermissionType.ACCESSIBILITY:
                    subprocess.run(["open", "x-apple.systempreferences:com.apple.preference.security?Privacy_Accessibility"], check=False)
                elif perm == PermissionType.INPUT_MONITORING:
                    subprocess.run(["open", "x-apple.systempreferences:com.apple.preference.security?Privacy_ListenEvent"], check=False)
        
        # После запроса обновляем статусы
        results = await self._refresh_permissions()
        await self._evaluate_permissions(results)
        
    except Exception as e:
        logger.error(f"❌ Ошибка запроса разрешений: {e}")
    finally:
        self._request_in_progress = False
```

---

## 📋 **ШАГ 5: Исправить _request_permissions_sequential**

```python
async def _request_permissions_sequential(self, missing: Dict[PermissionType, PermissionStatus]):
    """Последовательный запрос недостающих разрешений"""
    try:
        import asyncio
        import subprocess
        
        logger.info(f"🔔 Последовательный запрос: {[p.value for p in missing.keys()]}")
        
        # КРИТИЧНО: Захватываем event loop ДО определения handlers
        loop = asyncio.get_running_loop()
        
        # 1) Microphone
        if PermissionType.MICROPHONE in missing:
            logger.info("🎤 Запрашиваем Microphone...")
            mic_future = loop.create_future()
            
            def mic_handler(granted):
                try:
                    if not mic_future.done():
                        loop.call_soon_threadsafe(mic_future.set_result, bool(granted))
                except Exception as e:
                    if not mic_future.done():
                        loop.call_soon_threadsafe(mic_future.set_exception, e)
            
            try:
                AVCaptureDevice.requestAccessForMediaType_completionHandler_(AVMediaTypeAudio, mic_handler)
                mic_granted = await asyncio.wait_for(mic_future, timeout=30.0)
                logger.info(f"🎤 Microphone: {'granted' if mic_granted else 'denied'}")
                
                if mic_granted:
                    missing.pop(PermissionType.MICROPHONE, None)
            except asyncio.TimeoutError:
                logger.error("🎤 Microphone request timeout (30s)")
            except Exception as e:
                logger.error(f"🎤 Microphone request error: {e}")
        
        # 2) Accessibility
        if PermissionType.ACCESSIBILITY in missing:
            logger.info("♿ Запрашиваем Accessibility...")
            try:
                trusted = bool(AXIsProcessTrustedWithOptions({kAXTrustedCheckOptionPrompt: False}))
                
                if not trusted:
                    logger.info("⚠️ Accessibility не выдано, показываем диалог...")
                    trusted = bool(AXIsProcessTrustedWithOptions({kAXTrustedCheckOptionPrompt: True}))
                    
                    if not trusted:
                        logger.warning("⚠️ Accessibility отклонено пользователем")
                        subprocess.run(["open", "x-apple.systempreferences:com.apple.preference.security?Privacy_Accessibility"], check=False)
                    else:
                        logger.info("✅ Accessibility предоставлено")
                        missing.pop(PermissionType.ACCESSIBILITY, None)
                else:
                    logger.info("✅ Accessibility уже выдано")
                    missing.pop(PermissionType.ACCESSIBILITY, None)
            except Exception as e:
                logger.error(f"♿ Accessibility request error: {e}")
        
        # 3) Input Monitoring (через IOKit ctypes)
        if PermissionType.INPUT_MONITORING in missing:
            logger.info("⌨️ Запрашиваем Input Monitoring...")
            try:
                import ctypes
                IOHID_LISTEN_EVENT = 1
                
                if not hasattr(self, "_iokit"):
                    self._iokit = ctypes.CDLL("/System/Library/Frameworks/IOKit.framework/IOKit")
                    self._IOHIDCheckAccess = self._iokit.IOHIDCheckAccess
                    self._IOHIDCheckAccess.argtypes = [ctypes.c_uint32]
                    self._IOHIDCheckAccess.restype = ctypes.c_bool
                    self._IOHIDRequestAccess = self._iokit.IOHIDRequestAccess
                    self._IOHIDRequestAccess.argtypes = [ctypes.c_uint32]
                    self._IOHIDRequestAccess.restype = ctypes.c_int32
                
                has_im = bool(self._IOHIDCheckAccess(ctypes.c_uint32(IOHID_LISTEN_EVENT)))
                
                if not has_im and not self._input_monitoring_prompted:
                    logger.info("⚠️ Input Monitoring не выдано, запрашиваем...")
                    result = self._IOHIDRequestAccess(ctypes.c_uint32(IOHID_LISTEN_EVENT))
                    
                    if result == 0:
                        logger.info("✅ Input Monitoring предоставлено")
                        missing.pop(PermissionType.INPUT_MONITORING, None)
                    else:
                        logger.warning(f"⚠️ Input Monitoring отклонено (код: {result})")
                        subprocess.run(["open", "x-apple.systempreferences:com.apple.preference.security?Privacy_ListenEvent"], check=False)
                    
                    self._input_monitoring_prompted = True
                elif has_im:
                    logger.info("✅ Input Monitoring уже выдано")
                    missing.pop(PermissionType.INPUT_MONITORING, None)
                    
            except Exception as e:
                logger.error(f"⌨️ Input Monitoring request error: {e}")
        
        logger.info(f"✅ Последовательный запрос завершён. Осталось: {[p.value for p in missing.keys()]}")
        
    except Exception as e:
        logger.error(f"❌ Ошибка последовательного запроса: {e}")
```

---

## 📋 **ШАГ 6: Обновить start() метод**

```python
async def start(self) -> bool:
    """Запуск интеграции"""
    try:
        if not self.is_initialized:
            logger.error("PermissionsIntegration не инициализирован")
            return False
        
        if self.is_running:
            logger.warning("PermissionsIntegration уже запущен")
            return True
        
        logger.info("🚀 Запуск PermissionsIntegration...")
        
        # Проверяем доступность PyObjC
        if MACOS_IMPORTS_AVAILABLE:
            logger.info("✅ PyObjC доступен - автоматические диалоги включены")
        else:
            logger.warning("⚠️ PyObjC недоступен - только ручной запрос через System Settings")
        
        # Проверяем и запрашиваем разрешения
        results = await self._refresh_permissions()
        await self._evaluate_permissions(results)
        
        # Запускаем мониторинг
        await self.permission_manager.start_monitoring()
        self.is_monitoring = True
        
        self.is_running = True
        
        await self.event_bus.publish("permissions.integration_ready", {
            "integration": "permissions",
            "status": "running"
        })
        
        logger.info("✅ PermissionsIntegration запущен")
        return True
        
    except Exception as e:
        logger.error(f"❌ Ошибка запуска PermissionsIntegration: {e}")
        return False
```

---

## 📋 **ШАГ 7: Добавить проверку в SpeechRecognizer**

### Файл: `modules/voice_recognition/core/speech_recognizer.py`

```python
async def start_listening(self) -> bool:
    """Начинает прослушивание микрофона"""
    try:
        if self.state != RecognitionState.IDLE:
            logger.warning(f"⚠️ Невозможно начать прослушивание в состоянии {self.state.value}")
            return False
        
        # НОВОЕ: Проверяем разрешение микрофона перед запуском
        try:
            # Импортируем здесь чтобы избежать циклических зависимостей
            from modules.permissions.core.permissions_manager import PermissionsManager
            from modules.permissions.core.types import PermissionType, PermissionStatus
            
            # Создаем временный manager для проверки
            perm_manager = PermissionsManager()
            await perm_manager.initialize()
            
            mic_result = await perm_manager.check_permission(PermissionType.MICROPHONE)
            
            if mic_result.status != PermissionStatus.GRANTED:
                logger.error("❌ Microphone permission not granted")
                logger.info("ℹ️ Откройте System Settings → Privacy & Security → Microphone")
                return False
                
        except Exception as perm_error:
            logger.warning(f"⚠️ Не удалось проверить разрешение микрофона: {perm_error}")
            # Продолжаем попытку записи
        
        self.state = RecognitionState.LISTENING
        self.is_listening = True
        self.audio_data = []
        self.stop_event.clear()
        
        # ... остальной код ...
```

---

## 📋 **ШАГ 8: Обработать peak=0, rms=0**

### В `speech_recognizer.py` метод `_recognize_audio`:

```python
# После строки с логированием статистики
logger.info(
    "📈 Статистика аудио: chunks=%s, samples=%s, duration=%.2fs, peak=%.0f, rms=%.1f",
    len(self.audio_data),
    sample_count,
    duration_sec,
    peak,
    rms,
)

# НОВОЕ: Проверка нулевых данных
if peak == 0 and rms == 0.0:
    logger.error("❌ Микрофон не записывает звук (peak=0, rms=0)")
    logger.error("🔍 Возможные причины:")
    logger.error("   1. Разрешение Microphone не выдано")
    logger.error("   2. Выбран неправильный микрофон в System Settings")
    logger.error("   3. Микрофон заглушён (muted)")
    logger.info("ℹ️ Откройте System Settings → Sound → Input")
    
    return RecognitionResult(
        text="",
        error="Microphone not recording (silent input)"
    )
```

---

## ✅ **ИТОГО ИЗМЕНЕНИЙ:**

### Удалено:
- ❌ `self.permission_statuses` (кеш)
- ❌ `self._app_blocked`
- ❌ `_block_application()`
- ❌ `_unblock_application()`
- ❌ `_check_critical_permissions()`
- ❌ `_are_critical_permissions_granted()`
- ❌ Переходы в SLEEPING режим

### Добавлено:
- ✅ `_refresh_permissions()` - свежие статусы
- ✅ `_evaluate_permissions(results)` - оценка и запрос
- ✅ Параметр `missing` в `_request_required_permissions()`
- ✅ Event loop fix в `_request_permissions_sequential()`
- ✅ Проверка разрешений в `SpeechRecognizer.start_listening()`
- ✅ Обработка peak=0, rms=0
- ✅ Логирование для MACOS_IMPORTS_AVAILABLE=False

---

## 🧪 **ТЕСТИРОВАНИЕ:**

```bash
# 1. Пересборка
cd packaging
pyinstaller --clean --noconfirm Nexy.spec

# 2. Установка
sudo rm -rf /Applications/Nexy.app
sudo cp -R dist/Nexy.app /Applications/
sudo xattr -cr /Applications/Nexy.app

# 3. Сброс TCC
sudo tccutil reset All com.nexy.assistant

# 4. Тест
/Applications/Nexy.app/Contents/MacOS/Nexy

# Ожидается:
# ✅ "🔔 Последовательный запрос: ['microphone', 'accessibility', 'input_monitoring']"
# ✅ Диалоги появляются
# ✅ "✅ Все критичные разрешения предоставлены"
# ✅ "🎙️ Audio stream started"
# ✅ "🔊 First chunk received"
# ✅ "📈 Статистика аудио: peak > 0, rms > 0"

# 5. Проверка
./check_permissions.sh
# Должно показать 3x ✅ GRANTED
```

---

**Следующий шаг:** Применить изменения в коде и пересобрать!

