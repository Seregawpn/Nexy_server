# 🔐 Исправления логики разрешений (Permissions Fix)

**Дата:** 2025-10-11  
**Файл:** `integration/integrations/permissions_integration.py`

---

## 📋 Найденные проблемы

### 1️⃣ Разрешения НЕ запрашивались автоматически

**Проблема:** Строка 78
```python
self.critical_permissions = set()  # Пустое множество
```

**Эффект:**
- `_are_critical_permissions_granted()` всегда возвращала `True`
- Условие `if not await self._are_critical_permissions_granted()` никогда не срабатывало
- `_request_required_permissions()` никогда не вызывался
- Диалоги разрешений НЕ появлялись

**Исправление:** Строка 131-133
```python
# ВСЕГДА запрашиваем разрешения при старте
# (диалоги появятся только если не выданы)
await self._request_required_permissions()
```

---

### 2️⃣ Input Monitoring вообще НЕ запрашивался

**Проблема:**
- В комментарии написано "Accessibility/InputMonitoring"
- Но код для Input Monitoring отсутствовал полностью
- Запрашивались только Microphone, Screen Capture, Accessibility

**Эффект:**
- Input Monitoring никогда не проверялся
- Пользователь должен был включать вручную

**Исправление:** Строки 337-398
- Добавлен полноценный блок проверки Input Monitoring
- Используется системный API `IOHIDCheckAccess` (macOS 10.15+)
- Fallback к проверке TCC.db (user + system)
- Открытие System Settings если разрешения нет

---

### 3️⃣ Input Monitoring: некорректная проверка TCC.db

**Проблема:** Первая версия исправления (строка 335)
```python
# Проверяли ТОЛЬКО user TCC.db
tcc_db_path = os.path.expanduser("~/Library/Application Support/com.apple.TCC/TCC.db")
```

**Эффект:**
- Input Monitoring часто хранится в system TCC.db (`/Library/.../TCC.db`)
- Проверка всегда возвращала `False`
- System Settings открывались КАЖДЫЙ раз при запуске
- Навязчиво даже если разрешение уже выдано

**Исправление:** Строки 342-398

1. **Используем системный API** (приоритет):
   ```python
   from IOKit import IOHIDCheckAccess, kIOHIDRequestTypeListenEvent
   has_input_monitoring = bool(IOHIDCheckAccess(kIOHIDRequestTypeListenEvent))
   ```

2. **Fallback к TCC.db с двумя уровнями**:
   ```python
   # Сначала user DB
   user_result = check_tcc_db(user_tcc_db)
   # Если None → system DB
   if user_result is None:
       system_result = check_tcc_db(system_tcc_db)
   ```

3. **Флаг против повторного открытия**:
   ```python
   if not has_input_monitoring and not self._input_monitoring_prompted:
       subprocess.run(["open", "...Privacy_ListenEvent"], check=False)
       self._input_monitoring_prompted = True
   ```

---

## ✅ Итоговое поведение

### Первый запуск (разрешений нет)

1. **Microphone:**
   - Появится диалог → пользователь подтверждает

2. **Screen Capture:**
   - Появится диалог → пользователь подтверждает (если нужен)

3. **Accessibility:**
   - Появится диалог → пользователь подтверждает
   - Если отклонён → откроется System Settings

4. **Input Monitoring:**
   - Проверка через `IOHIDCheckAccess()` или TCC.db (user + system)
   - Если нет → откроется System Settings **ОДИН РАЗ**
   - Флаг `_input_monitoring_prompted = True`

### Второй и последующие запуски (разрешения выданы)

1. **Microphone:** Проверка без диалога → `True` → ничего не делаем ✓
2. **Accessibility:** Проверка без диалога → `True` → ничего не делаем ✓
3. **Input Monitoring:** `IOHIDCheckAccess()` → `True` → ничего не делаем ✓

**Никакие диалоги НЕ появляются!** ✅  
**System Settings НЕ открывается!** ✅

### Повторная проверка в рамках сессии

Если `_request_required_permissions()` вызывается повторно:
- `_input_monitoring_prompted` уже `True`
- System Settings НЕ открывается ✓

---

## 🎯 Ключевые улучшения

| До | После |
|---|---|
| ❌ Разрешения не запрашивались | ✅ Запрашиваются автоматически |
| ❌ Input Monitoring отсутствовал | ✅ Полная проверка и запрос через IOHID API |
| ❌ Только user TCC.db | ✅ **IOHID API** (источник истины) + fallback к TCC.db |
| ❌ Settings открываются всегда | ✅ Один раз за сессию |
| ❌ Навязчиво после выдачи | ✅ Умная проверка статуса |
| ❌ Нет интеграции с EventBus | ✅ Отправка событий `permissions.status_changed` |

### 💡 Почему IOHID API?

**Единственный надёжный способ узнать статус Input Monitoring:**
- ✅ Прямой доступ к TCC без чтения базы данных
- ✅ Корректно работает когда разрешение в system TCC.db
- ✅ Позволяет ЗАПРАШИВАТЬ разрешение через диалог (`IOHIDRequestAccess`)
- ✅ Не требует root доступа
- ✅ Официальный Apple API (macOS 10.15+)

---

## 🔍 Техническая детализация

### Проверка Accessibility (строки 313-335)

```python
# 1. Проверка БЕЗ диалога
trusted = AXIsProcessTrustedWithOptions({kAXTrustedCheckOptionPrompt: False})

# 2. Если нет → показываем диалог
if not trusted:
    trusted = AXIsProcessTrustedWithOptions({kAXTrustedCheckOptionPrompt: True})
    
    # 3. Если снова отклонён → открываем настройки
    if not trusted:
        subprocess.run(["open", "...Privacy_Accessibility"], check=False)
```

### Проверка Input Monitoring (строки 337-452) - IOHID API как источник истины

```python
# 1. Используем IOHID API - единственный надёжный способ узнать статус TCC
try:
    from IOKit import HID
    
    # IOHIDCheckAccess возвращает булево значение (True/False)
    check_result = HID.IOHIDCheckAccess(HID.kIOHIDRequestTypeListenEvent)
    has_input_monitoring = bool(check_result)  # True = выдано, False = нет
    
    if not has_input_monitoring and not self._input_monitoring_prompted:
        # Инициируем запрос через системный API (асинхронный диалог)
        # IOHIDRequestAccess возвращает числовой код (0 = kIOReturnSuccess)
        request_result = HID.IOHIDRequestAccess(HID.kIOHIDRequestTypeListenEvent)
        
        if request_result == 0:  # kIOReturnSuccess
            has_input_monitoring = True
        else:
            # Открываем System Settings для ручного включения (ОДИН РАЗ)
            subprocess.run(["open", "...Privacy_ListenEvent"], check=False)
        
        self._input_monitoring_prompted = True

except ImportError:
    # 2. Fallback: IOHID API недоступен (старый рантайм)
    # Проверяем TCC.db (user → system), трактуем ошибки как "неизвестно"
    user_result = check_tcc_db("~/Library/.../TCC.db")
    if user_result is None:
        system_result = check_tcc_db("/Library/.../TCC.db")

# 3. Обновляем статус и отправляем событие на EventBus
self.permission_statuses[PermissionType.INPUT_MONITORING] = input_monitoring_status
await self.event_bus.publish("permissions.status_changed", {...})
```

**⚠️ ВАЖНО: Типы возвращаемых значений**

| Функция | Возвращает | Значение |
|---------|-----------|----------|
| `IOHIDCheckAccess()` | **bool** | `True` = доступ выдан<br>`False` = доступа нет |
| `IOHIDRequestAccess()` | **int** | `0` = kIOReturnSuccess (выдано)<br>`!= 0` = ошибка/отказ |

**🚨 КРИТИЧЕСКАЯ ОШИБКА (исправлена):**

В первой версии была ошибка сравнения:
```python
# ❌ НЕПРАВИЛЬНО (было):
SUCCESS = 0
check_result = HID.IOHIDCheckAccess(...)
has_input_monitoring = (check_result == SUCCESS)  # Переворачивает логику!

# Если доступ выдан: True == 0 → False (НЕПРАВИЛЬНО!)
# Если доступа нет: False == 0 → True в Python (НЕПРАВИЛЬНО!)

# ✅ ПРАВИЛЬНО (стало):
check_result = HID.IOHIDCheckAccess(...)
has_input_monitoring = bool(check_result)  # Просто булево значение!
```

Это приводило к тому, что при **выданном** разрешении приложение считало, что его **нет**, и снова триггерило диалог + открывало System Settings каждый раз!

---

## 📚 Рекомендации для тестирования

### ✅ Полный цикл тестирования (рекомендуется перед релизом)

```bash
# 1️⃣ Очистить все TCC разрешения
sudo tccutil reset Accessibility com.nexy.assistant
sudo tccutil reset Microphone com.nexy.assistant
sudo tccutil reset ListenEvent com.nexy.assistant
sudo tccutil reset ScreenCapture com.nexy.assistant

# 2️⃣ Запустить приложение (первый запуск)
open /Applications/Nexy.app

# 3️⃣ Ожидаемое поведение при ПЕРВОМ запуске:
#    ✅ Появится диалог Microphone → подтвердите
#    ✅ Появится диалог Accessibility → подтвердите
#    ✅ Появится диалог Input Monitoring (через IOHIDRequestAccess) → подтвердите
#    ℹ️ Если диалог Input Monitoring отклонён → откроется System Settings
#    ℹ️ Screen Capture запросится при первом скриншоте

# 4️⃣ Удержите пробел и проверьте что микрофон активируется
#    ✅ Должна начаться запись голоса
#    ✅ Нет ошибки CoreAudio Error 35
#    ✅ Нет ошибки CGEventTap failed

# 5️⃣ Проверка статуса через IOHID API
python3 << 'EOF'
from IOKit import HID
result = HID.IOHIDCheckAccess(HID.kIOHIDRequestTypeListenEvent)
print(f"Input Monitoring статус: {result} (булево)")
EOF
#    ✅ Должно вернуть: True (булево значение)

# 6️⃣ Перезапустить приложение (второй запуск)
pkill Nexy
sleep 2
open /Applications/Nexy.app

# 7️⃣ Ожидаемое поведение при ПОВТОРНОМ запуске:
#    ✅ Никакие диалоги НЕ появляются
#    ✅ System Settings НЕ открывается
#    ✅ В логах: "✅ Input Monitoring уже выдано"
#    ✅ В логах: "✅ Accessibility уже выдано"
#    ✅ В логах: IOHIDCheckAccess результат: True (булево)

# 8️⃣ Финальная проверка через check_permissions.sh
./check_permissions.sh

#    ✅ Ожидаемый результат:
#    ✅ Microphone: РАЗРЕШЕНО
#    ✅ Accessibility: РАЗРЕШЕНО  
#    ✅ Input Monitoring: РАЗРЕШЕНО
```

### 🔍 Проверка логов

```bash
# Посмотреть последние логи приложения
tail -100 ~/Library/Application\ Support/Nexy/logs/nexy_*.log | grep -E "(Input Monitoring|IOHIDCheckAccess|IOHIDRequestAccess|permissions.status_changed)"

# Ожидаемые строки при первом запуске:
# "⌨️ Проверка Input Monitoring..."
# "IOHIDCheckAccess результат: False (булево)"  # НЕ выдано
# "⚠️ Input Monitoring не выдано, запрашиваем через IOHID API..."
# "IOHIDRequestAccess результат: 0"  # kIOReturnSuccess!
# "✅ Input Monitoring разрешение выдано через диалог"

# Ожидаемые строки при повторном запуске:
# "⌨️ Проверка Input Monitoring..."
# "IOHIDCheckAccess результат: True (булево)"  # Выдано!
# "✅ Input Monitoring уже выдано"
```

---

## 🔗 Связанные файлы

- `integration/integrations/permissions_integration.py` — основной файл изменений
- `check_permissions.sh` — скрипт проверки разрешений
- `fix_tcc_cache.sh` — автоматическое исправление проблем с TCC
- `QUICK_PERMISSIONS_CHECK.md` — документация для пользователей
- `SUPPORT_PLAYBOOK.md` — руководство для службы поддержки

---

## 📝 Changelog

**2025-10-11 (v2 - КРИТИЧЕСКОЕ ИСПРАВЛЕНИЕ):**
- 🚨 **ИСПРАВЛЕНА критическая ошибка в `IOHIDCheckAccess`**
  - Было: `has_input_monitoring = (check_result == 0)` — переворачивало логику!
  - Стало: `has_input_monitoring = bool(check_result)` — корректно
  - Причина: `IOHIDCheckAccess` возвращает **bool**, а не числовой код
- ✅ `IOHIDRequestAccess` по-прежнему сравнивается с `0` (возвращает **int**)
- ✅ Обновлена документация с правильными типами возвращаемых значений

**2025-10-11 (v1):**
- ✅ Исправлена проблема с пустым `critical_permissions`
- ✅ Добавлен запрос Input Monitoring
- ✅ Реализована проверка через `IOHIDCheckAccess` API
- ✅ Добавлен fallback к system TCC.db
- ✅ Добавлен флаг `_input_monitoring_prompted` против повторного открытия
- ✅ Корректная обработка `PermissionError` при чтении TCC.db
- ✅ Интеграция с EventBus

---

**Статус:** ✅ Готово к пересборке и тестированию

