# 🗑️ Файлы для удаления

**Дата:** 2025-10-12  
**Цель:** Очистка проекта перед рефакторингом

---

## 📋 **КАТЕГОРИИ:**

### 1️⃣ **Временные тестовые файлы** (7 файлов)

```bash
test_event_flow.py                    # Временный тест событий
test_simple_press.py                  # Временный тест клавиш
test_pyaudio_20251009_145136.wav      # Тестовая аудио-запись
test_installed_app.sh                 # Временный скрипт
test_new_build.sh                     # Временный скрипт
run.sh                                # Простой run - есть run_with_venv.sh
utils/                                # Пустая директория
```

**Размер:** ~100 KB

---

### 2️⃣ **Устаревшая документация** (11 файлов)

```bash
PERMISSION_DIALOG_FIX.md              # Старое описание проблемы (решена)
PERMISSIONS_FIX_SUMMARY.md            # Старое (будет новое после рефакторинга)
PERMISSIONS_IMPLEMENTATION_FINAL.md  # Старое (устарело)
PERMISSIONS_REFACTOR_PLAN.md         # v1 (заменён на v2)
CRITICAL_FIXES_SUMMARY.md            # Старое
BUNDLE_ID_ISSUE_ANALYSIS.md          # Проблема решена
FINAL_DEPLOYMENT_STATUS.md           # Старый статус
PACKAGING_SUCCESS_REPORT.md          # Старый отчёт
TEST_RESULTS_SUMMARY.md              # Старые результаты
PACKAGING_CHECKLIST.md               # Устаревший чеклист
PACKAGING_EXECUTION_PLAN.md          # Устаревший план
```

**Размер:** ~100 KB

---

### 3️⃣ **Устаревшие скрипты** (13 файлов)

```bash
check_bundle_mismatch.sh             # Одноразовая проверка (завершена)
fix_bundle_id_cache.sh               # Одноразовый фикс (применён)
fix_tcc_cache.sh                     # Дубликат функциональности
diagnose_audio.sh                    # Временный диагностический
diagnose_permissions.sh              # Временный диагностический
health_check.sh                      # Дубликат (есть check_permissions.sh)
postinstall_healthcheck.sh           # Не используется в PKG
quick_test.sh                        # Дубликат (есть quick_install_and_test.sh)
run_smoke_test.sh                    # Старый (заменён на full_permissions_test.sh)
smoke_test_permissions.sh            # Старый
watch_logs.sh                        # Временный
packaging/reset_permissions.sh       # Одноразовый
packaging/setup_installer_cert.sh    # Одноразовая настройка
```

**Размер:** ~50 KB

---

### 4️⃣ **Старые логи** (11 файлов)

```bash
rebuild_logs/build_20251011_191032.log
rebuild_logs/rebuild_20251011_191032.log
rebuild_logs/build_20251011_201105.log
rebuild_logs/rebuild_20251011_201105.log
rebuild_logs/build_20251011_231222.log
rebuild_logs/rebuild_20251011_231222.log
rebuild_logs/build_20251012_002557.log
rebuild_logs/rebuild_20251012_002557.log
rebuild_logs/build_20251012_095716.log
rebuild_logs/rebuild_20251012_095716.log
rebuild_execution.log
```

**Размер:** ~5-10 MB (зависит от размера логов)

---

### 5️⃣ **Резервные копии** (после успешного рефакторинга)

```bash
integration/integrations/permissions_integration.py.backup
```

**Размер:** ~30 KB

---

## ✅ **ОСТАВЛЯЕМ (важные):**

### Скрипты:
- ✅ `check_permissions.sh` - проверка разрешений
- ✅ `clean_reinstall.sh` - полная переустановка
- ✅ `full_permissions_test.sh` - полный тест
- ✅ `quick_install_and_test.sh` - быстрая установка
- ✅ `rebuild_from_scratch.sh` - production сборка
- ✅ `run_with_venv.sh` - запуск с venv
- ✅ `packaging/build_final.sh` - основной скрипт сборки

### Документация:
- ✅ `PERMISSIONS_REFACTOR_PLAN_V2.md` - текущий план
- ✅ `REFACTOR_IMPLEMENTATION_NOTES.md` - заметки
- ✅ `RELEASE_NOTES_v1.0.1.md` - release notes
- ✅ `V1.0.1_RELEASE_CHECKLIST.md` - чеклист релиза
- ✅ `FINAL_BUILD_INSTRUCTIONS.md` - инструкции
- ✅ `FINAL_SUMMARY.md` - общий статус
- ✅ `SUPPORT_PLAYBOOK.md` - для поддержки
- ✅ `QUICK_PERMISSIONS_CHECK.md` - для пользователей
- ✅ `PERMISSIONS_TOOLS_README.md` - описание инструментов
- ✅ `REBUILD_GUIDE.md` - руководство по сборке
- ✅ `REBUILD_SCRIPT_FIXES.md` - исправления скриптов
- ✅ `MACOS_PACKAGING_REQUIREMENTS.md` - требования
- ✅ `PACKAGING_MASTER_PLAN.md` - мастер-план (если актуален)
- ✅ `PERMISSIONS_REPORT.md` - отчёт о разрешениях
- ✅ `Docs/` - вся основная документация

---

## 📊 **ИТОГО К УДАЛЕНИЮ:**

- **Файлов:** 42
- **Размер:** ~5-10 MB
- **Польза:** Чистый проект, легче навигация

---

## 🚀 **КОМАНДА ДЛЯ УДАЛЕНИЯ:**

```bash
cd /Users/sergiyzasorin/Development/Nexy/client

# Создаём архив удаляемых файлов (на всякий случай)
mkdir -p .deleted_files_backup
tar -czf .deleted_files_backup/deleted_$(date +%Y%m%d_%H%M%S).tar.gz \
    test_event_flow.py \
    test_simple_press.py \
    test_pyaudio_20251009_145136.wav \
    test_installed_app.sh \
    test_new_build.sh \
    run.sh \
    PERMISSION_DIALOG_FIX.md \
    PERMISSIONS_FIX_SUMMARY.md \
    PERMISSIONS_IMPLEMENTATION_FINAL.md \
    PERMISSIONS_REFACTOR_PLAN.md \
    CRITICAL_FIXES_SUMMARY.md \
    BUNDLE_ID_ISSUE_ANALYSIS.md \
    FINAL_DEPLOYMENT_STATUS.md \
    PACKAGING_SUCCESS_REPORT.md \
    TEST_RESULTS_SUMMARY.md \
    PACKAGING_CHECKLIST.md \
    PACKAGING_EXECUTION_PLAN.md \
    check_bundle_mismatch.sh \
    fix_bundle_id_cache.sh \
    fix_tcc_cache.sh \
    diagnose_audio.sh \
    diagnose_permissions.sh \
    health_check.sh \
    postinstall_healthcheck.sh \
    quick_test.sh \
    run_smoke_test.sh \
    smoke_test_permissions.sh \
    watch_logs.sh \
    rebuild_execution.log \
    rebuild_logs/*.log \
    utils/ \
    2>/dev/null

# Удаляем файлы
rm -f test_event_flow.py
rm -f test_simple_press.py
rm -f test_pyaudio_20251009_145136.wav
rm -f test_installed_app.sh
rm -f test_new_build.sh
rm -f run.sh
rm -f PERMISSION_DIALOG_FIX.md
rm -f PERMISSIONS_FIX_SUMMARY.md
rm -f PERMISSIONS_IMPLEMENTATION_FINAL.md
rm -f PERMISSIONS_REFACTOR_PLAN.md
rm -f CRITICAL_FIXES_SUMMARY.md
rm -f BUNDLE_ID_ISSUE_ANALYSIS.md
rm -f FINAL_DEPLOYMENT_STATUS.md
rm -f PACKAGING_SUCCESS_REPORT.md
rm -f TEST_RESULTS_SUMMARY.md
rm -f PACKAGING_CHECKLIST.md
rm -f PACKAGING_EXECUTION_PLAN.md
rm -f check_bundle_mismatch.sh
rm -f fix_bundle_id_cache.sh
rm -f fix_tcc_cache.sh
rm -f diagnose_audio.sh
rm -f diagnose_permissions.sh
rm -f health_check.sh
rm -f postinstall_healthcheck.sh
rm -f quick_test.sh
rm -f run_smoke_test.sh
rm -f smoke_test_permissions.sh
rm -f watch_logs.sh
rm -f rebuild_execution.log
rm -f rebuild_logs/*.log
rm -f packaging/reset_permissions.sh
rm -f packaging/setup_installer_cert.sh
rm -rf utils/

echo "✅ Удалено 42 файла"
echo "📦 Резервная копия: .deleted_files_backup/deleted_*.tar.gz"
```

---

## ❓ **ПОДТВЕРЖДЕНИЕ:**

Удалить все файлы из списка?
- ✅ **ДА** - выполнить команду выше
- ❌ **НЕТ** - пересмотреть список
- 📝 **ЧАСТИЧНО** - выбрать конкретные файлы

