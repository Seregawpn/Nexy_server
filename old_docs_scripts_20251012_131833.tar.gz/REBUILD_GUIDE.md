# 🔄 Руководство по полной пересборке Nexy с нуля

**Дата создания:** 2025-10-11  
**Цель:** Устранение всех артефактов старых сборок и TCC кэша

---

## 🎯 Когда использовать

Используйте полную пересборку, если:
- ✅ Изменили Bundle ID
- ✅ Наблюдаете ошибки TCC `"failed to find Application URL"`
- ✅ Диалоги разрешений не появляются
- ✅ Хотите получить чистый CDHash для notarization
- ✅ После изменений в entitlements или Info.plist
- ✅ Перед финальным релизом

---

## 📋 Что делает скрипт

### Автоматизирует 13 этапов:

1. **Очистка окружения**
   - Удаляет `build/`, `dist/`
   - Удаляет `/Applications/Nexy.app`
   - Размонтирует DMG
   - Очищает Python кэш

2. **Сброс TCC разрешений**
   - Удаляет записи для `com.nexy.assistant`
   - Очищает старые записи для `Nexy`, `com.sergiyzasorin.nexy.voiceassistant`
   - Работает с пользовательской и системной TCC базой

3. **Сброс Launch Services кэша**
   - Полный сброс `-kill -r`
   - Ожидание стабилизации системы

4. **Сборка через PyInstaller**
   - Запускает `packaging/build_final.sh`
   - Логирует весь процесс
   - Проверяет наличие артефактов

5-10. **Подпись и Notarization**
   - Подпись .app с entitlements
   - Notarization .app через Apple
   - Staple .app
   - Создание PKG
   - Notarization PKG
   - Staple PKG

11. **(Опционально) DMG**
   - Создание, если настроено в `build_final.sh`

12. **Финальная проверка spctl**
   - `spctl --assess` для .app
   - `spctl --assess --type install` для .pkg
   - `codesign --verify --deep --strict`
   - Проверка Info.plist

13. **Установка и тестирование**
   - Установка PKG через `installer`
   - Перерегистрация в Launch Services
   - Запуск из терминала
   - Проверка логов и TCC событий

---

## 🚀 Как использовать

### Простой вариант:

```bash
cd /Users/sergiyzasorin/Development/Nexy/client
./rebuild_from_scratch.sh
```

Скрипт **интерактивный** - будет делать паузы на ключевых этапах для проверки.

### С автоматическим продолжением:

```bash
yes "" | ./rebuild_from_scratch.sh
```

(Не рекомендуется для первого раза)

---

## ⏱️ Время выполнения

| Этап | Время |
|------|-------|
| Очистка окружения | 1-2 мин |
| Сброс TCC и Launch Services | 1 мин |
| Сборка PyInstaller | 5-7 мин |
| Подпись .app | 30 сек |
| Notarization .app | 3-5 мин |
| Создание PKG | 1 мин |
| Notarization PKG | 3-5 мин |
| Финальные проверки | 1 мин |
| **ИТОГО** | **15-20 мин** |

---

## 📊 Ожидаемый результат

### ✅ Успешная пересборка:

```
╔══════════════════════════════════════════════════════════════════════════╗
║                         📋 ИТОГОВЫЙ ОТЧЁТ                                ║
╚══════════════════════════════════════════════════════════════════════════╝

АРТЕФАКТЫ:

   ✅ dist/Nexy.app
   ✅ dist/Nexy.pkg
   ✅ dist/Nexy.dmg (опционально)

ПРОВЕРКИ:

   ✅ spctl .app
   ✅ spctl .pkg
   ✅ codesign --verify
   ✅ Установка в /Applications
   ✅ Приложение запущено (PID: 12345)
```

### В логах приложения должны быть:

```
✅ Все macOS системные импорты успешно загружены
🚫 Блокировка приложения - отсутствуют критичные разрешения
🔐 Запускаем запрос разрешений...
```

### НЕ должно быть:

```
❌ tccd: failed to find Application URL
❌ errAETimeout
❌ macOS системные импорты недоступны
```

---

## 🔍 Диагностика проблем

### Если сборка не удалась:

```bash
# Смотрим полный лог
cat rebuild_logs/rebuild_YYYYMMDD_HHMMSS.log

# Смотрим лог build_final.sh
cat rebuild_logs/build_YYYYMMDD_HHMMSS.log

# Проверяем ошибки PyInstaller
grep -i error rebuild_logs/build_YYYYMMDD_HHMMSS.log
```

### Если notarization не прошла:

```bash
# Получить детали notarization
xcrun notarytool log <submission-id> \
  --keychain-profile NexyNotary \
  notarization_log.json

# Проверить причину отказа
cat notarization_log.json | jq '.issues'
```

### Если приложение упало:

```bash
# Crash report
ls -lt ~/Library/Logs/DiagnosticReports/Nexy*.crash | head -1
cat $(ls -t ~/Library/Logs/DiagnosticReports/Nexy*.crash | head -1)

# Лог первого запуска
cat /tmp/nexy_first_launch.log

# Логи приложения
tail -100 ~/Library/Application\ Support/Nexy/logs/*.log
```

---

## 🛠️ Требования

### Система:
- macOS 13.0+
- Xcode Command Line Tools
- Python 3.11+
- Права администратора (sudo)

### Credentials:
- Developer ID Application certificate (для подписи .app)
- Developer ID Installer certificate (для подписи .pkg)
- Keychain profile `NexyNotary` для notarization

### Проверка credentials:

```bash
# Проверить сертификаты
security find-identity -v -p codesigning

# Проверить keychain profile
xcrun notarytool history --keychain-profile NexyNotary

# Проверить sudo доступ
sudo -v
```

---

## ⚠️ Важные особенности

### 1. System Integrity Protection (SIP)

Системная TCC база (`/Library/Application Support/com.apple.TCC/TCC.db`) защищена SIP и не может быть изменена напрямую при включённом SIP (по умолчанию).

Скрипт:
- ✅ Использует `sudo tccutil reset` для корректного сброса разрешений
- ✅ Пытается очистить системную базу, но не падает при отказе
- ✅ Логирует предупреждение, если SIP защищает базу

**Это нормально и не мешает работе!**

### 2. Launch Services кэш

Команда `lsregister -kill -r` перестраивает все базы приложений на системе.

**Побочные эффекты:**
- Другие приложения могут временно выдавать ошибки
- В системных логах появятся предупреждения
- Finder может "подвиснуть" на 1-2 секунды

**Это нормально!** Система восстанавливается за несколько секунд.

### 3. GUI приложение

Приложение запускается через `open /Applications/Nexy.app` (правильный способ на macOS), а не напрямую через бинарник.

**Преимущества:**
- ✅ Корректная обработка системных событий
- ✅ Нет `errAETimeout` ошибок
- ✅ Правильный запрос разрешений
- ✅ Логи сохраняются в стандартное место

### 4. Совместимость

Скрипт не использует GNU-specific команды:
- ❌ Нет `timeout` (не установлен по умолчанию на macOS)
- ✅ Вместо этого используется `perl -e 'alarm 5'`
- ✅ Динамическое определение PROJECT_ROOT
- ✅ Автоматическое продление sudo на всё время работы

---

## 📝 Логи

Все логи сохраняются в `rebuild_logs/`:

```
rebuild_logs/
├── rebuild_20251011_190000.log  # Полный лог всех этапов
├── build_20251011_190000.log    # Лог build_final.sh
└── ...
```

Дополнительные логи:
- `/tmp/nexy_first_launch.log` - лог первого запуска
- `~/Library/Application Support/Nexy/logs/` - логи приложения

---

## 🔐 Безопасность

### Что делает sudo:
- Удаление `/Applications/Nexy.app`
- Очистка системной TCC базы (`/Library/Application Support/com.apple.TCC/TCC.db`)
- Установка PKG через `installer`

### Что НЕ требует sudo:
- Сборка через PyInstaller
- Подпись .app и .pkg
- Notarization
- Запуск приложения

---

## 🎯 После пересборки

1. **Проверить разрешения:**
   ```bash
   ./check_permissions.sh
   ```

2. **Запустить smoke test:**
   ```bash
   ./full_permissions_test.sh
   ```

3. **Проверить системные логи:**
   ```bash
   log stream --predicate 'subsystem contains "tccd" and message contains "nexy"' --level debug
   ```

4. **Если всё работает:**
   - Сохранить артефакты из `dist/`
   - Обновить версию в `Info.plist`
   - Создать Git tag
   - Распространять `dist/Nexy.pkg`

---

## 🆘 Поддержка

### Если что-то пошло не так:

1. **Сохраните логи:**
   ```bash
   tar -czf nexy_rebuild_logs.tar.gz rebuild_logs/ /tmp/nexy_first_launch.log
   ```

2. **Проверьте документацию:**
   - `FINAL_DEPLOYMENT_STATUS.md` - итоговый статус
   - `BUNDLE_ID_ISSUE_ANALYSIS.md` - проблемы с Bundle ID
   - `SUPPORT_PLAYBOOK.md` - playbook для диагностики

3. **Проверьте базовые вещи:**
   ```bash
   # Python версия
   python3 --version  # Должно быть 3.11+
   
   # Сертификаты
   security find-identity -v -p codesigning
   
   # Keychain profile
   xcrun notarytool history --keychain-profile NexyNotary
   
   # PyInstaller
   pip3 show pyinstaller
   ```

---

## ⚡ Быстрые команды

```bash
# Полная пересборка
./rebuild_from_scratch.sh

# Только очистка без пересборки
./clean_reinstall.sh

# Только установка существующего PKG
sudo installer -pkg dist/Nexy.pkg -target /

# Только проверка артефактов
spctl --assess --verbose dist/Nexy.app
spctl --assess --type install dist/Nexy.pkg
codesign --verify --deep --strict dist/Nexy.app

# Только smoke test
./full_permissions_test.sh
```

---

## 📚 Связанные документы

- **`FINAL_DEPLOYMENT_STATUS.md`** - итоговый статус развёртывания
- **`BUNDLE_ID_ISSUE_ANALYSIS.md`** - анализ проблемы Bundle ID кэша
- **`PERMISSIONS_FIX_SUMMARY.md`** - описание всех исправлений разрешений
- **`QUICK_PERMISSIONS_CHECK.md`** - руководство для пользователей
- **`SUPPORT_PLAYBOOK.md`** - playbook для технической поддержки
- **`Docs/packaging/09_FINAL_RELEASE.md`** - процесс финального релиза

---

**Создано:** AI Assistant  
**Последнее обновление:** 2025-10-11 19:15  
**Версия:** 1.0.0

