# 📝 Заметки по внедрению рефакторинга разрешений

**Дата:** 2025-10-12  
**План:** PERMISSIONS_REFACTOR_PLAN_V2.md

---

## ✅ **УТОЧНЕНИЯ ОТ ПОЛЬЗОВАТЕЛЯ:**

### 1. critical_permissions
```python
# Текущий список
self.critical_permissions = {
    PermissionType.MICROPHONE,       # Обязательно
    PermissionType.ACCESSIBILITY,    # Обязательно
    PermissionType.INPUT_MONITORING, # Обязательно
}

# SCREEN_CAPTURE - опциональный, запрашивается при первом скриншоте
# Не добавляем в critical_permissions, чтобы не блокировать старт
```

### 2. DI для permissions_integration
```python
# ❌ НЕ ДЕЛАТЬ:
coordinator = self.event_bus._coordinator

# ✅ ПРАВИЛЬНО:
class VoiceRecognitionIntegration(BaseIntegration):
    def __init__(self, event_bus, error_handler, config, permissions_integration=None):
        super().__init__(event_bus, error_handler, config)
        self.permissions_integration = permissions_integration
```

### 3. Перехват ошибок в _refresh_permissions
```python
except Exception as e:
    logger.error(f"❌ КРИТИЧЕСКАЯ ОШИБКА обновления разрешений: {e}")
    logger.error(f"   Используем старый кэш: {self._cached_results is not None}")
    import traceback
    logger.error(traceback.format_exc())
    return self._cached_results if self._cached_results else {}
```

### 4. Голосовые подсказки
```python
# Вариант 1: subprocess.run(["say", text])  - простой, но только англ.
# Вариант 2: через SpeechPlaybackIntegration - лучше, поддерживает кастомные звуки

async def _speak_permission_instructions(self, missing):
    try:
        # Формируем текст
        perm_names = [p.value for p in missing.keys()]
        text = f"Nexy requires permissions: {', '.join(perm_names)}"
        
        # Отправляем через EventBus в SpeechPlaybackIntegration
        await self.event_bus.publish("speech.speak", {
            "text": text,
            "priority": "high",
            "voice": "system"  # или кастомный голос
        })
        
        # Дублируем через say для надёжности (если SpeechPlayback недоступен)
        import subprocess
        subprocess.run(["say", text], check=False)
        
    except Exception as e:
        logger.error(f"❌ Ошибка голосового оповещения: {e}")
```

---

## 📋 **ПОРЯДОК ВНЕДРЕНИЯ:**

### Этап 1: Базовая инфраструктура (30 мин)
- [ ] 1.1. Добавить лёгкий кэш с TTL в PermissionsIntegration
- [ ] 1.2. Новый метод `_refresh_permissions(force=False)`
- [ ] 1.3. Новый метод `_evaluate_permissions(results)`
- [ ] 1.4. Удалить старые методы блокировки
- [ ] 1.5. Обновить `start()` метод

### Этап 2: Dependency Injection (15 мин)
- [ ] 2.1. Добавить `permissions_integration` параметр в конструкторы
- [ ] 2.2. SimpleModuleCoordinator: сохранить ссылку
- [ ] 2.3. VoiceRecognitionIntegration: принять и передать в SpeechRecognizer
- [ ] 2.4. InputProcessingIntegration: принять ссылку
- [ ] 2.5. ScreenshotCaptureIntegration: принять ссылку

### Этап 3: Проверки перед действиями (20 мин)
- [ ] 3.1. SpeechRecognizer: проверка перед `start_listening()`
- [ ] 3.2. SpeechRecognizer: обработка peak=0, rms=0
- [ ] 3.3. InputProcessingIntegration: проверка перед обработкой событий
- [ ] 3.4. ScreenshotCaptureIntegration: проверка перед захватом

### Этап 4: Синхронизация в sequential (15 мин)
- [ ] 4.1. Обновить `_request_permissions_sequential()`
- [ ] 4.2. Добавить `force=True` refresh после каждого диалога
- [ ] 4.3. Обновлять `missing` на основе реальных данных TCC

### Этап 5: Голосовые подсказки (10 мин)
- [ ] 5.1. Реализовать `_speak_permission_instructions()`
- [ ] 5.2. Интеграция с SpeechPlaybackIntegration
- [ ] 5.3. Fallback на `subprocess.run(["say", ...])`

### Этап 6: События и миграция (10 мин)
- [ ] 6.1. Найти подписчиков `permissions.app_blocked/unblocked`
- [ ] 6.2. Заменить на новые события
- [ ] 6.3. Удалить публикацию старых событий

### Этап 7: Smoke-тесты (10 мин)
- [ ] 7.1. Обновить quick_install_and_test.sh
- [ ] 7.2. Добавить sudo проверки
- [ ] 7.3. Обновить check_permissions.sh
- [ ] 7.4. Создать полный smoke-тест

### Этап 8: Тестирование (20 мин)
- [ ] 8.1. Пересборка
- [ ] 8.2. Установка
- [ ] 8.3. Сброс TCC
- [ ] 8.4. Первый запуск (должны появиться диалоги)
- [ ] 8.5. Проверка разрешений
- [ ] 8.6. Тест записи (peak > 0)
- [ ] 8.7. Второй запуск (без диалогов)

---

## 🎯 **КРИТЕРИИ УСПЕХА:**

1. ✅ При запуске появляются 3 диалога (Microphone, Accessibility, Input Monitoring)
2. ✅ После подтверждения `./check_permissions.sh` показывает 3x GRANTED
3. ✅ При удержании пробела появляется "🔊 First chunk received"
4. ✅ "📈 Статистика аудио: peak > 0, rms > 0.X"
5. ✅ При повторном запуске диалоги НЕ появляются
6. ✅ При сбросе TCC диалоги появляются снова
7. ✅ Нет блокировки приложения (нет перехода в SLEEPING)
8. ✅ Голосовые подсказки работают при MACOS_IMPORTS_AVAILABLE=False

---

## 🚀 **НАЧИНАЕМ С ЭТАПА 1**

Готов приступить к внедрению!

