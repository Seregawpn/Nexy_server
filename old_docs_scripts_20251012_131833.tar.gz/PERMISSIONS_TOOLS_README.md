# 🔐 Nexy Permissions Tools

Набор инструментов для диагностики и исправления проблем с разрешениями macOS.

---

## 🚀 Быстрый старт

### Если приложение не работает:

```bash
./health_check.sh
```

Покажет что не так и что делать.

### Автоматическое исправление:

```bash
./fix_tcc_cache.sh
```

Интерактивный скрипт исправит проблему за 2 минуты.

---

## 📦 Состав

### 🔍 Диагностика

| Скрипт | Описание | Время |
|--------|----------|-------|
| `health_check.sh` | Комплексная проверка всех компонентов | 30 сек |
| `check_permissions.sh` | Быстрая проверка разрешений TCC | 10 сек |
| `check_bundle_mismatch.sh` | Поиск несоответствий Bundle ID | 1 мин |
| `diagnose_permissions.sh` | Полная диагностика с рекомендациями | 1 мин |

### 🛠️ Исправление

| Скрипт | Описание | Время |
|--------|----------|-------|
| `fix_tcc_cache.sh` | Автоматическое исправление (интерактивно) | 2 мин |
| `test_installed_app.sh` | Полный тест с перезагрузкой приложения | 1 мин |
| `watch_logs.sh` | Мониторинг логов в реальном времени | постоянно |

### 📚 Документация

| Файл | Описание | Аудитория |
|------|----------|-----------|
| `QUICK_PERMISSIONS_CHECK.md` | Краткая справка | Пользователи |
| `SUPPORT_PLAYBOOK.md` | Руководство с типовыми сценариями | Служба поддержки |
| `postinstall_healthcheck.sh` | Скрипт для интеграции в PKG | Разработчики |

---

## 📋 Типовые сценарии

### Сценарий 1: Первая установка

```bash
# После установки PKG
./health_check.sh

# Если разрешений нет
./fix_tcc_cache.sh
# Следуйте инструкциям
```

### Сценарий 2: Галочки есть, но не работает

```bash
# Проверьте несоответствие
./check_bundle_mismatch.sh

# Исправьте автоматически
./fix_tcc_cache.sh
```

### Сценарий 3: После обновления

```bash
# Полная диагностика
./diagnose_permissions.sh

# Если нужно - сброс и повторный запрос
pkill -9 Nexy
sudo killall -9 tccd
sudo tccutil reset All com.nexy.assistant
open /Applications/Nexy.app
```

### Сценарий 4: Мониторинг в реальном времени

```bash
# Терминал 1: логи
./watch_logs.sh

# Терминал 2: тестирование
open /Applications/Nexy.app
# Нажмите ПРОБЕЛ и говорите
```

---

## 🎯 Интеграция в релизы

### 1. Постустановочный скрипт

Добавьте в `build_final.sh`:

```bash
# Создать директорию для скриптов
mkdir -p packaging/scripts

# Скопировать postinstall
cp postinstall_healthcheck.sh packaging/scripts/postinstall
chmod +x packaging/scripts/postinstall

# Добавить в pkgbuild
pkgbuild ... \
  --scripts packaging/scripts/ \
  ...
```

### 2. Встроенная проверка в приложение

В `permissions_integration.py` добавьте self-check:

```python
def check_permissions_on_startup(self):
    """Проверка разрешений при старте"""
    missing = []
    
    if not self._check_microphone():
        missing.append("Microphone")
    
    if not self._check_accessibility():
        missing.append("Accessibility")
    
    if missing:
        self._show_permissions_dialog(missing)
```

### 3. Телеметрия

Собирайте анонимную статистику:

```python
analytics.track("permissions_check", {
    "granted": ["microphone", "accessibility"],
    "missing": ["input_monitoring"],
    "auto_fixed": True,
    "macos_version": "14.0"
})
```

---

## 🔧 Для разработчиков

### Локальное тестирование

```bash
# Сброс разрешений
sudo tccutil reset All com.nexy.assistant

# Пересборка и переустановка
./packaging/build_final.sh
sudo installer -pkg dist/Nexy.pkg -target /

# Health check
./health_check.sh

# Мониторинг
./watch_logs.sh
```

### Сбор диагностической информации

```bash
# Для отправки в баг-репорт
./diagnose_permissions.sh > diagnostic_report.txt
tar -czf nexy_logs.tar.gz ~/Library/Application\ Support/Nexy/logs/
log show --predicate 'processImagePath contains "Nexy"' --last 1h > system_logs.txt
```

---

## 📊 Понимание проблемы

### Архитектура разрешений macOS

```
┌─────────────────────────────────────────────┐
│  macOS TCC (Transparency, Consent, Control) │
│                                             │
│  ~/Library/Application Support/             │
│    com.apple.TCC/TCC.db (SQLite)           │
│                                             │
│  Хранит:                                    │
│  • Bundle ID приложения                     │
│  • Тип разрешения (Microphone, etc.)        │
│  • Статус (allowed: 0/1)                    │
│  • Timestamp                                │
└─────────────────────────────────────────────┘
           ↑                  ↑
           │                  │
     ЗАПРАШИВАЕТ          ПРОВЕРЯЕТ
           │                  │
    ┌──────────────────────────────┐
    │  Nexy.app                    │
    │  (com.nexy.assistant)        │
    │                              │
    │  permissions_integration.py  │
    └──────────────────────────────┘
```

### Почему возникает проблема

1. **TCC кэш не обновился**
   - System Settings UI показывает одно
   - TCC.db содержит другое
   - Решение: перезапуск `tccd`

2. **Bundle ID изменился**
   - Переподпись с другим Team ID
   - Разрешения привязаны к старому ID
   - Решение: сброс и повторный запрос

3. **Разрешения для другого пути**
   - Было: `/Users/x/Downloads/Nexy.app`
   - Стало: `/Applications/Nexy.app`
   - Решение: удалить старое, запросить для нового

### CoreAudio Error 35

```
Нет разрешения Microphone
      ↓
macOS блокирует доступ к аудио устройству
      ↓
CoreAudio API возвращает error 35
      ↓
sounddevice.InputStream не стартует
      ↓
Нет данных для распознавания
```

---

## 💡 Best Practices

### Для пользователей

1. Всегда устанавливайте из PKG (не перетаскивайте из Downloads)
2. При первом запуске подтвердите ВСЕ системные диалоги
3. Если проблемы - запустите `./health_check.sh`

### Для поддержки

1. Первый запрос - попросите `./health_check.sh`
2. Используйте `SUPPORT_PLAYBOOK.md` для типовых сценариев
3. Эскалируйте с полной диагностикой (`diagnose_permissions.sh`)

### Для разработчиков

1. Тестируйте на чистой системе (сброшенные разрешения)
2. Проверяйте Bundle ID и подпись после каждой сборки
3. Добавляйте логирование в критические места
4. Собирайте телеметрию о проблемах с разрешениями

---

## 🆘 Получение помощи

### Самостоятельно

1. `./health_check.sh` - что не так
2. `./fix_tcc_cache.sh` - автоматическое исправление
3. `QUICK_PERMISSIONS_CHECK.md` - подробные инструкции

### Служба поддержки

1. Отправьте вывод `./diagnose_permissions.sh`
2. Приложите скриншот System Settings → Privacy
3. Укажите версию macOS и Nexy

### Разработка

1. Создайте issue на GitHub
2. Приложите:
   - `diagnostic_report.txt`
   - `nexy_logs.tar.gz`
   - `system_logs.txt`
   - Шаги воспроизведения

---

## 📝 FAQ

**Q: Почему разрешения не сохраняются после перезагрузки?**  
A: Проверьте Bundle ID - возможно, приложение запускается из другого места.

**Q: Галочки стоят, но приложение говорит что нет разрешений?**  
A: Запустите `./fix_tcc_cache.sh` - проблема в кэше TCC daemon.

**Q: Можно ли выдать разрешения программно?**  
A: Нет, только пользователь может выдать разрешения через System Settings или системные диалоги.

**Q: Почему после обновления нужно выдавать разрешения заново?**  
A: Если изменился Bundle ID или Team ID в подписи, macOS считает это другим приложением.

---

## 🔗 Ссылки

- [Apple TCC Documentation](https://developer.apple.com/documentation/bundleresources/entitlements)
- [macOS Security and Privacy Guide](https://support.apple.com/guide/mac-help/control-access-to-your-mac-mchl211c911f/mac)
- Внутренний Wiki: [ссылка]

---

**Версия:** 1.0  
**Дата:** 2025-10-11  
**Автор:** Nexy Development Team

