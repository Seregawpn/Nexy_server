#!/bin/bash

set -e

cat << 'EOF'

╔══════════════════════════════════════════════════════════════════════════╗
║     🚀 УСТАНОВКА И ТЕСТИРОВАНИЕ НОВОЙ СБОРКИ                            ║
╚══════════════════════════════════════════════════════════════════════════╝

✅ Новая сборка готова в: packaging/dist/Nexy.app

Сейчас выполним:
1. Остановка старого приложения
2. Удаление /Applications/Nexy.app
3. Копирование новой версии
4. Очистка extended attributes
5. Сброс TCC разрешений
6. Запуск для теста

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

EOF

echo "🛑 Останавливаем старое приложение..."
pkill -9 Nexy 2>/dev/null || echo "   (процесс не запущен)"
sleep 1

echo "🗑️  Удаляем старую версию..."
sudo rm -rf /Applications/Nexy.app

echo "📦 Копируем новую сборку..."
sudo cp -R /Users/sergiyzasorin/Development/Nexy/client/packaging/dist/Nexy.app /Applications/

echo "🔓 Очищаем extended attributes..."
sudo xattr -cr /Applications/Nexy.app

echo "🔄 Сбрасываем TCC разрешения..."
sudo tccutil reset All com.nexy.assistant 2>/dev/null || echo "   (TCC уже чист)"

echo ""
echo "✅ Установка завершена!"
echo ""
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo ""
echo "🎤 ТЕСТИРОВАНИЕ:"
echo ""
echo "Сейчас запустится приложение из терминала."
echo ""
echo "📋 ЧТО ДЕЛАТЬ:"
echo "   1. Появятся 3 диалога - подтвердите все"
echo "   2. УДЕРЖИВАЙТЕ ПРОБЕЛ 3-5 секунд"
echo "   3. ГОВОРИТЕ В МИКРОФОН громко и чётко"
echo "   4. Отпустите пробел"
echo "   5. Нажмите Ctrl+C чтобы остановить"
echo ""
echo "🔍 ЧТО ИЩЕМ В ЛОГАХ:"
echo "   ✅ '🔔 Старт последовательного запроса прав...'"
echo "   ✅ '🎤 Microphone: granted'"
echo "   ✅ '♿ Проверка Accessibility...'"
echo "   ✅ '⌨️ Проверка Input Monitoring...'"
echo "   ✅ '🎙️ Audio stream started'"
echo "   ✅ '🔊 First chunk received'"
echo "   ✅ '📈 Статистика аудио: peak > 0'"
echo ""
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo ""
echo "Запуск через 5 секунд..."
echo ""
sleep 5

echo "🚀 ЗАПУСК:"
echo ""

# Запускаем и фильтруем важные логи
/Applications/Nexy.app/Contents/MacOS/Nexy 2>&1 | grep -E \
    "(🔔 Старт последовательного запроса|🎤 Microphone:|♿ Проверка Accessibility|⌨️ Проверка Input|🎙️ Audio stream|🔊 First chunk|📈 Статистика аудио|критичные разрешения|разблокировка|error|ошибка)" \
    --line-buffered --color=auto || true

