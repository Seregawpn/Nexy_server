# 🔐 Быстрая проверка разрешений Nexy

## 📋 Итог по текущей ситуации

### 🔐 Кто управляет разрешениями?

| Сторона | Роль |
|---------|------|
| 🍎 macOS | Хранит разрешения в TCC.db (user или system) |
| 👤 Пользователь | Подтверждает системные диалоги и переключатели |
| 📱 Nexy | Запрашивает разрешения через официальные Apple API |

### 🎯 Как Nexy запрашивает разрешения

| Разрешение | API | Как работает |
|-----------|-----|--------------|
| 🎤 Microphone | `AVCaptureDevice.requestAccessForMediaType` | Системный диалог при первом запуске |
| ♿ Accessibility | `AXIsProcessTrustedWithOptions` | Системный диалог при первом запуске |
| ⌨️ Input Monitoring | **`IOKit.HID.IOHIDRequestAccess`** | **Системный диалог (IOHID API)** |
| 📸 Screen Capture | `CGRequestScreenCaptureAccess` | Диалог при первом скриншоте |

**💡 Input Monitoring использует IOHID API:**
- ✅ Единственный надёжный способ узнать статус TCC
- ✅ Прямой запрос разрешения через системный диалог
- ✅ Работает даже когда разрешение в system TCC.db
- ✅ Не требует root доступа

### ⚠️ Симптом

```
Галочки в System Settings стоят   ✓
       ↓
TCC.db пуста                      ❌
       ↓
CoreAudio error 35                💥
```

**Причина:** кэш TCC или разрешения выданы для другого Bundle ID/пути приложения.

### ✅ Ожидаемое поведение (UX)

**🎯 ПЕРВЫЙ ЗАПУСК (разрешений нет):**

1. Запускаете Nexy → появляется диалог **Microphone** → подтверждаете ✓
2. Появляется диалог **Accessibility** → подтверждаете ✓
3. Появляется диалог **Input Monitoring** (через IOHID API) → подтверждаете ✓
4. Если какой-то диалог отклонён → автоматически откроется System Settings
5. **Один раз** за запуск — больше никаких диалогов!

**🔄 ПОВТОРНЫЕ ЗАПУСКИ (разрешения есть):**

1. Запускаете Nexy → **никакие диалоги НЕ появляются** ✓
2. System Settings **НЕ открывается** ✓
3. Приложение сразу готово к работе ✓

### ✅ Быстрое решение при проблемах

1. Запустите `./fix_tcc_cache.sh`
2. Следуйте интерактивным подсказкам (проверка списка, сброс TCC, перезапуск)
3. По завершении перепроверьте `./check_permissions.sh`

Если автоматический сценарий недоступен, используйте вручную описанные шаги ниже.

## Диагностика

### Быстрая проверка разрешений
```bash
./check_permissions.sh
```

Покажет статус всех 4 критических разрешений:
- 🎤 **Microphone** — доступ к микрофону
- ⌨️ **Input Monitoring** — мониторинг клавиатуры (для пробела)
- ♿ **Accessibility** — контроль системы
- 📸 **Screen Recording** — снимки экрана (опционально)

### Полная диагностика
```bash
./diagnose_permissions.sh
```

Покажет:
- Статус установки приложения
- Текущие разрешения TCC
- Аудио устройства
- Логи приложения
- Рекомендации по исправлению

## Решение

### ✅ Простой способ

1. **Запустите приложение:**
   ```bash
   open /Applications/Nexy.app
   ```

2. **Нажмите и держите ПРОБЕЛ** 2-3 секунды

3. **Подтвердите все диалоги:**
   - Accessibility → Открыть настройки → Включить → Готово
   - Microphone → OK
   - Input Monitoring → OK

4. **Проверьте результат:**
   ```bash
   ./check_permissions.sh
   ```

### 🔧 Если диалоги не появились

Включите разрешения вручную:

1. Откройте **System Settings** (⚙️)
2. **Privacy & Security**
3. Включите Nexy в:
   - ♿ Accessibility
   - 🎤 Microphone  
   - ⌨️ Input Monitoring
   - 📸 Screen Recording
4. Перезапустите:
   ```bash
   pkill Nexy && open /Applications/Nexy.app
   ```

### 🔄 Если нужно сбросить

```bash
sudo tccutil reset Microphone com.nexy.assistant
sudo tccutil reset ListenEvent com.nexy.assistant
sudo tccutil reset Accessibility com.nexy.assistant
sudo tccutil reset ScreenCapture com.nexy.assistant
```

Затем снова запустите приложение и подтвердите диалоги.

## Тестирование после выдачи разрешений

### Терминал 1: Мониторинг
```bash
./watch_logs.sh
```

### Терминал 2: Тестирование
```bash
# Запустите приложение (если не запущено)
open /Applications/Nexy.app

# Нажмите и держите ПРОБЕЛ, говорите 2-3 секунды
```

### ✅ Что должно быть в логах

- `Audio stream started`
- `chunks=X` (где X > 0)
- `Распознано: [ваш текст]`
- `gRPC sending request`

### ❌ Чего НЕ должно быть

- `HALC_ProxyIOContext::_StartIO(): Start failed`
- `error 35`
- `Нет аудио данных`
- `запись слишком короткая`

## Полезные команды

| Команда | Описание |
|---------|----------|
| `./check_permissions.sh` | Быстрая проверка разрешений |
| `./check_bundle_mismatch.sh` | Проверка несоответствия Bundle ID |
| `./fix_tcc_cache.sh` | Исправление проблем с TCC кэшем (интерактивно) |
| `./diagnose_permissions.sh` | Полная диагностика |
| `./watch_logs.sh` | Мониторинг логов в реальном времени |
| `./test_installed_app.sh` | Полный тест с перезагрузкой |
| `pkill Nexy` | Остановить приложение |
| `open /Applications/Nexy.app` | Запустить приложение |
| `sudo killall -9 tccd` | Перезапустить TCC daemon (сброс кэша) |

## Статус сборки

✅ **PKG** (95M) — полностью подписан и нотаризован
- Developer Certificate: ✅
- Apple Notary Service: ✅
- Timestamp: 2025-10-11 14:57:46 UTC

## Изменения в последней версии

1. ✅ **Accessibility Prompt** — показывается только при первом запуске
2. ✅ **PKG Payload** — исправлена критическая ошибка (tar → cpio)
3. ✅ **PyObjC** — все модули упакованы корректно
4. ✅ **AppleDouble** — очистка перед подписью

---

**🚀 Начните с этого:**
```bash
open /Applications/Nexy.app
# Затем нажмите ПРОБЕЛ и подтвердите диалоги!
```
